import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'

export const Route = createFileRoute('/')({
  component: Home,
})

function Home() {
  return (
    <div className="min-h-screen bg-white text-gray-800 font-sans">
      <Navbar />
      <Hero />
      <About />
      <Services />
      <Testimonials />
      <Contact />
      <Footer />
    </div>
  )
}

function Navbar() {
  return (
    <nav className="fixed top-0 w-full bg-white/80 backdrop-blur-md z-50 border-b border-pink-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-pink-500 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-xl">A</span>
            </div>
            <span className="text-xl font-semibold tracking-tight text-pink-600">
              Angel J’s Smile
            </span>
          </div>
          <div className="hidden md:flex space-x-8 items-center text-sm font-medium text-gray-600">
            <a href="#about" className="hover:text-pink-500 transition-colors">About</a>
            <a href="#services" className="hover:text-pink-500 transition-colors">Services</a>
            <a href="#reviews" className="hover:text-pink-500 transition-colors">Reviews</a>
            <a href="#contact" className="bg-pink-500 text-white px-6 py-2.5 rounded-full hover:bg-pink-600 transition-all shadow-md hover:shadow-lg">
              Book Appointment
            </a>
          </div>
        </div>
      </div>
    </nav>
  )
}

function Hero() {
  return (
    <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
      {/* Background blobs */}
      <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-[600px] h-[600px] bg-pink-50 rounded-full blur-3xl opacity-50 -z-10" />
      <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-[400px] h-[400px] bg-pink-100 rounded-full blur-3xl opacity-30 -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="inline-block px-4 py-1.5 mb-6 text-sm font-medium text-pink-600 bg-pink-50 rounded-full border border-pink-100">
          Welcome to Gentle Care
        </div>
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-gray-900 mb-6 leading-tight">
          Your Smile Deserves <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-pink-300">
            Gentle, Expert Care
          </span>
        </h1>
        <p className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto mb-10 leading-relaxed">
          A friendly and professional dental clinic that makes every visit comfortable and stress-free. We care for your smile as much as you do.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a href="#contact" className="px-8 py-4 bg-pink-500 text-white rounded-full font-semibold shadow-lg shadow-pink-200 hover:bg-pink-600 transition-all transform hover:-translate-y-1">
            Book an Appointment
          </a>
          <a href="#contact" className="px-8 py-4 bg-white text-pink-600 border-2 border-pink-100 rounded-full font-semibold hover:border-pink-500 transition-all transform hover:-translate-y-1">
            Contact Us
          </a>
        </div>
      </div>
    </section>
  )
}

function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <div className="aspect-square bg-pink-100 rounded-3xl overflow-hidden relative shadow-inner">
               {/* Placeholder for dental clinic image */}
               <div className="absolute inset-0 flex items-center justify-center text-pink-300">
                 <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24">
                   <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                 </svg>
               </div>
            </div>
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-pink-500 rounded-2xl flex items-center justify-center p-4 text-white text-center shadow-xl">
              <div>
                <div className="text-2xl font-bold">100%</div>
                <div className="text-xs">Gentle Care</div>
              </div>
            </div>
          </div>
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Patient-Focused Care You Can Trust</h2>
            <p className="text-gray-600 text-lg mb-6 leading-relaxed">
              At Angel J’s Smile Dental Clinic, we believe dentistry should be approachable and stress-free. Our team is dedicated to being friendly, professional, and highly accommodating to your needs.
            </p>
            <p className="text-gray-600 text-lg mb-8 leading-relaxed">
              We specialize in making first-time patients feel right at home. With clear explanations and a gentle touch, we ensure you know exactly what to expect at every step of your oral health journey.
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-pink-100 flex items-center justify-center text-pink-600">✓</div>
                <span className="font-medium text-gray-700">Gentle Care</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-pink-100 flex items-center justify-center text-pink-600">✓</div>
                <span className="font-medium text-gray-700">Expert Team</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-pink-100 flex items-center justify-center text-pink-600">✓</div>
                <span className="font-medium text-gray-700">Modern Tech</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-pink-100 flex items-center justify-center text-pink-600">✓</div>
                <span className="font-medium text-gray-700">Cozy Clinic</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function Services() {
  const services = [
    { title: "Dental Check-ups", desc: "Thorough examinations to keep your smile healthy." },
    { title: "Teeth Cleaning", desc: "Professional cleaning for a brighter, fresher smile." },
    { title: "Tooth Extraction", desc: "Gentle and precise extractions when you need them." },
    { title: "Dental Consultation", desc: "Expert advice tailored to your oral health needs." },
    { title: "Oral Health Advice", desc: "Tips and guidance for maintaining perfect hygiene." },
    { title: "Cosmetic Dentistry", desc: "Enhance your smile with our aesthetic treatments." },
  ]

  return (
    <section id="services" className="py-20 bg-pink-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Services</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Comprehensive dental care delivered with a soft touch. Explore our wide range of professional treatments.
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white p-8 rounded-2xl border border-pink-100 hover:border-pink-300 hover:shadow-xl hover:shadow-pink-100 transition-all group">
              <div className="w-12 h-12 bg-pink-50 rounded-xl mb-6 flex items-center justify-center text-pink-500 group-hover:bg-pink-500 group-hover:text-white transition-colors">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
              <p className="text-gray-600 leading-relaxed">{service.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function Testimonials() {
  const reviews = [
    {
      name: "Milkie Dones",
      initial: "M",
      text: "Highly recommended if you're looking for a very friendly dental clinic. Thumbs up kay Doc Mae and sa lahat ng staff 😊 Thank you so much po 💗",
    },
    {
      name: "Nicole Ragaas",
      initial: "N",
      text: "All of them are very accommodating and reliable, they will feed you all of the informations that you're supposed to know. I highly recommend this clinic! They're very professional yet friendly 🥰🥰",
    },
    {
      name: "Myca Ciocon",
      initial: "M",
      text: "Staff's are so accommodating. Dentists are so professional, they takes time to explain what needs to be done and provides valuable advice. They are so friendly and goes extra mile to make you feel comfortable. Kudos and highest recommendation 🫶",
    },
    {
      name: "Rayzon Managuelod",
      initial: "R",
      text: "Nice staff, and good service. Super approachable ng mga staff. Thanks to Doc Mae and to all the staff 🫶",
    },
    {
      name: "Conde, Cristal Mae",
      initial: "C",
      text: "Very accommodating staff and very friendly. Has professional dentist, kind and friendly also. Best clinic I've been to so far. You won't regret having them to take care of your teeth. 5 stars!",
    },
    {
      name: "Jelly Rose Sambial",
      initial: "J",
      text: "Very relaxing and accommodating clinic I’ve ever been. Will recommend this 100%!! 🫰",
    },
  ]

  return (
    <section id="reviews" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Patient Stories</h2>
          <p className="text-gray-600">What our wonderful patients have to say about their experience.</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <div key={index} className="bg-white p-8 rounded-2xl border border-pink-100 shadow-sm hover:shadow-md transition-shadow flex flex-col">
              <div className="flex items-center gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className="text-pink-400">★</span>
                ))}
              </div>
              <p className="text-gray-600 italic mb-8 flex-grow">"{review.text}"</p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center text-pink-600 font-bold text-lg border-2 border-pink-200 shadow-sm">
                  {review.initial}
                </div>
                <div>
                  <div className="font-bold text-gray-900">{review.name}</div>
                  <div className="text-xs text-pink-500 font-medium">Verified Patient</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function Contact() {
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 3000)
  }

  return (
    <section id="contact" className="py-20 bg-pink-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Book Your Visit Today</h2>
            <p className="text-gray-600 mb-10 text-lg">
              Ready for a stress-free dental experience? Fill out the form or reach out to us directly. We can't wait to see your smile!
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm text-pink-500">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                </div>
                <div>
                  <div className="text-sm text-gray-500 uppercase tracking-wider font-semibold">Phone</div>
                  <div className="text-gray-900 font-medium">+63 (000) 123 4567</div>
                </div>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm text-pink-500">
                   <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
                <div>
                  <div className="text-sm text-gray-500 uppercase tracking-wider font-semibold">Address</div>
                  <div className="text-gray-900 font-medium">Angel J's Smile Dental Clinic, City Center</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 md:p-10 rounded-3xl shadow-xl shadow-pink-100 border border-pink-50">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                  <input type="text" required className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500 transition-all" placeholder="Jane Doe" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                  <input type="tel" required className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500 transition-all" placeholder="0912 345 6789" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Service Needed</label>
                <select className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500 transition-all appearance-none">
                  <option>Dental Check-up</option>
                  <option>Teeth Cleaning</option>
                  <option>Tooth Extraction</option>
                  <option>Consultation</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                <textarea rows={4} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500 transition-all" placeholder="How can we help you?"></textarea>
              </div>
              <button type="submit" disabled={submitted} className={`w-full py-4 rounded-xl font-bold text-white shadow-lg transition-all transform active:scale-95 ${submitted ? 'bg-green-500' : 'bg-pink-500 hover:bg-pink-600 shadow-pink-200'}`}>
                {submitted ? 'Message Sent!' : 'Book Your Visit Today'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="py-12 border-t border-pink-100 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-8">
        <div className="flex items-center gap-2 text-pink-600 font-semibold text-lg">
          <div className="w-8 h-8 bg-pink-500 rounded-full flex items-center justify-center text-white text-sm">A</div>
          Angel J's Smile
        </div>
        <div className="text-gray-500 text-sm">
          © {new Date().getFullYear()} Angel J's Smile Dental Clinic. All rights reserved.
        </div>
        <div className="flex gap-6">
           <a href="#" className="text-gray-400 hover:text-pink-500 transition-colors">Facebook</a>
           <a href="#" className="text-gray-400 hover:text-pink-500 transition-colors">Instagram</a>
        </div>
      </div>
    </footer>
  )
}
